AmCharts.translations.dataLoader.cs = {
  'Error loading the file': 'Došlo k chybě při načítání souboru',
  'Error parsing JSON file': 'Chyba při zpracování JSON souboru',
  'Unsupported data format': 'Nepodporovaný formát souboru',
  'Loading data...': 'Načítám data...'
}